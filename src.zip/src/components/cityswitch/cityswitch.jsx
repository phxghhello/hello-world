import React, { Component } from 'react';
import './cityswitch.css';
import City from '../city/city';
import store from '../../pages/store';


class Cityswitch extends Component {
    constructor(props){
        super(props);
        this.state = {
            sCurrentCity:store.getState().label,
            sClass:"city_wrap"
        }

        // 订阅数据中心的修改
        this.unsubscribe = store.subscribe( this.fnStoreChange )

    }

    // 重新去拿当前城市，将城市名称设置到state中
    fnStoreChange=()=>{
        this.setState({
            sCurrentCity:store.getState().label
        })
    }

    componentWillUnmount(){
        this.unsubscribe()
    }


    fnSwitch=(sClass)=>{
        this.setState({
            sClass
        })
    }

    render() {
        let { sCurrentCity,sClass } = this.state;
        return (
            <div className="search_con">
                <span className="city" onClick={ ()=>this.fnSwitch("city_wrap slideUp") }>{sCurrentCity}</span>
                <i className="iconfont icon-xialajiantouxiangxia"></i>
                <span className="village"><i className="iconfont icon-fangdajing"></i> 请输入小区名</span>
                <City sClass={ sClass } fnSwitch={ this.fnSwitch } />
            </div>
        );
    }
}

export default Cityswitch;