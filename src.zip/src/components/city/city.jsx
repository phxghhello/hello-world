import React, { Component } from 'react';
import './city.css';
import store from '../../pages/store';

import { Toast } from 'antd-mobile';

// 导入可视区渲染组件(做长列表优化)和列表尺寸自适应组件
import {List,AutoSizer} from 'react-virtualized';


/* 
当前城市的数据：
[
    {label: "北京", value: "AREA|88cff55c-aaa4-e2e0", pinyin: "beijing", short: "bj"},
    {label: "安庆", value: "AREA|b4e8be1a-2de2-e039", pinyin: "anqing", short: "aq"},
    {label: "南宁", value: "AREA|2bc437ca-b3d2-5c3c", pinyin: "nanning", short: "nn"},
    {label: "长沙", value: "AREA|98b03413-6f84-c263", pinyin: "changsha", short: "cs"},
    {label: "武汉", value: "AREA|27e414ce-a7e1-fd99", pinyin: "wuhan", short: "wh"},
    {label: "重庆", value: "AREA|df130a14-79a9-a2ca", pinyin: "zhongqing", short: "zq"},
    {label: "青岛", value: "AREA|0941e83b-fe11-b392", pinyin: "qingdao", short: "qd"},
]

现在我们需要的数据结构是：
{
    a:[{label: "安庆", value: "AREA|b4e8be1a-2de2-e039", pinyin: "anqing", short: "aq"}],
    b:[{label: "北京", value: "AREA|88cff55c-aaa4-e2e0", pinyin: "beijing", short: "bj"},
       {label: "北海", value: "AREA|88cff55c-aaa4-e2e0", pinyin: "beihai", short: "bh"}
    ],
    c:[{label: "长沙", value: "AREA|98b03413-6f84-c263", pinyin: "changsha", short: "cs"},]
    ....
}

['a','b','c','d'.....]

*/

function fnFormatData(aList){
    let oCityList = {};

    for(var i=0;i<aList.length;i++){
        // 得到key对应的字母
        let sLetter = aList[i].short.substr(0,1);

        // 判断对象中是否包含某个key
        if(sLetter in oCityList){
            // 如果包含，说明对象中有这个key对应的键值对，就把新的城市数据push到这个key对应的数组中
            oCityList[sLetter].push( aList[i] )
        }else{
            // 如果不包含，就在对象中创建一个键值对，键是sLetter，值是一个数组，数组的第一个成员是aList[i]
            oCityList[sLetter] = [ aList[i] ]
        }
    }

    // 使用内置方法，生成对象的key组成的数组,同时将数组安装字母顺序排序
    let aCitykey = Object.keys( oCityList ).sort();

    //return {oCityList:oCityList,aCitykey:aCitykey}
    return {oCityList,aCitykey}

}

// 定义一个函数来转换城市列表的名称
// 将”#“转换成当前定位，将”hot“转换为热门城市，将小写字母转换成大写字母
function fnFormatLetter(sTr){
    if(sTr==='#'){
        return '当前定位';
    }else if(sTr==='hot'){
        return '热门城市';
    }else{
        // toUpperCase()是将小写转换成大写的方法
        return sTr.toUpperCase()
    }
}


class City extends Component {
    constructor(props){
        super(props);
        this.state = {
            oCurrentCity:store.getState(),
            oCityList:{},
            aCitykey:[],
            iCurrentIndex:2
        }        
        // 订阅数据中心的修改
        this.unsubscribe = store.subscribe( this.fnStoreChange );

        // 创建ref对象
        this.oRef = React.createRef();

    }

    fnStoreChange=()=>{
        this.setState({
            oCurrentCity:store.getState()         
        // 在setState的回调函数中再去设置另外的属性的值
        // 这个回调函数会在setState操作完成之后执行
        },()=>{
            // 修改oCityList里面”#“对应的值
            // 将它的值改成新的当前城市
            this.setState(state=>{
                let oNowCityList = state.oCityList;
                oNowCityList['#'] = [ state.oCurrentCity ];
                return {
                    oCityList:oNowCityList
                }
            })
        })
    } 

    componentWillUnmount(){
        this.unsubscribe()
    }

    componentDidMount(){
        this.fnGetData()
    }

    fnGetData=async ()=>{
        // 定义变量来存储所有城市数据(它是一个数组)
        let aNowAllCityData;
        // 去缓存获取所有城市的字符串
        let sNowAllCityData = localStorage.getItem('haoke_all_city_Data');
        // 如果有，将这个字符串转换成对象存到aNowAllCityData中
        if(sNowAllCityData){
            aNowAllCityData = JSON.parse( sNowAllCityData );            
        }else{
            // 如果没有，就去请求所有城市数据，把返回的数据存到aNowAllCityData中，同时再存到本地缓存
            let oRes = await this.axios.get('/area/city?level=1');
            aNowAllCityData = oRes.data.body;
            localStorage.setItem('haoke_all_city_Data',JSON.stringify( oRes.data.body ))
        }


        // 格式化返回的数据
        let {oCityList,aCitykey} = fnFormatData( aNowAllCityData );        
        //console.log(oCityList,aCitykey);

        let aHotCity;
        let sHotCity = localStorage.getItem('haoke_hot_city');
        if(sHotCity){
            aHotCity = JSON.parse( sHotCity );
        }else{
            // 将格式化的数据在加上热门城市
            let oRes2 = await this.axios.get('/area/hot');
            aHotCity = oRes2.data.body;
            localStorage.setItem('haoke_hot_city',JSON.stringify( oRes2.data.body ))
        }
      
        //console.log(oRes2.data.body);
        oCityList['hot'] = aHotCity;
        aCitykey.unshift('hot');

        // 在加上当前城市的数据
        oCityList['#'] = [this.state.oCurrentCity];
        aCitykey.unshift('#');
        // console.log(oCityList,aCitykey);

        // 将最终的数据更新到state中
        this.setState({
            oCityList,
            aCitykey
        })

    }

    fnSentCity=async sName=>{
        // alert(sName);
        // 判断点击的城市名称是否是当前城市，如果是
        // 就提示用户当前城市已选
        if(sName===this.state.oCurrentCity.label){
            Toast.info('当前城市已选！',2);
        }else{
            // 将点击的城市名称传到一个接口中来验证这个城市是否在公司业务范围内
            let oRes = await this.axios.get('/area/info?name='+sName);
            //console.log(oRes.data.body);

            //如果传递的城市名在公司业务范围内，就返回这个城市，如果不在公司业务范围内
            //就返回上海的城市数据
            // 如果点击的不是上海，但是返回的是上海的城市数据，说明点击的城市不在公司业务范围内
            // 就不把这个城市设置为当前城市
            // 如果不满足上面的条件，说明点击的城市在公司业务范围内，那么就把这个城市设置为当前城市
            if(sName!=='上海'&&oRes.data.body.label==='上海'){
                Toast.info('当前城市没有数据',2);
            }else{
                // 提交到数据中心
                store.dispatch({
                    type:'change_current_city',
                    value:oRes.data.body
                })

                // 存储到本地缓存
                sessionStorage.setItem('haoke_current_city',JSON.stringify( oRes.data.body ))
                
                // 关闭城市列表页面
                this.props.fnSwitch("city_wrap");
            
            }
        }

    }

    rowRenderer=({key,index,style})=>{
        // 通过传入的index索引值拿到aCitykey对应的字母
        let sLetter = this.state.aCitykey[index];

        // 通过字母对应的key拿到oCityList对应的数组
        let aList = this.state.oCityList[sLetter];

        return (
            // key使用函数传入的key，style使用函数传入的style
            // 这个style很重要，是它里面做列表布局样式的，一定要加上
            <div className="city_group" key={ key } style={ style }>
                <h4>{fnFormatLetter(sLetter)}</h4>
                <ul>
                    {
                        aList.map(val=>(<li key={ val.value } onClick={ ()=>this.fnSentCity(val.label) }>{val.label}</li>))
                    }                                    
                </ul>
            </div> 
        )
    }

    // 定义方法来动态计算高度
    fnCountHeight=({index})=>{
          // 通过传入的index索引值拿到aCitykey对应的字母
        let sLetter = this.state.aCitykey[index];

        // 通过字母对应的key拿到oCityList对应的数组的长度
        let iLen = this.state.oCityList[sLetter].length;

        return 40 + 58*iLen;
    }

    // 定义列表滚动时触发的方法
    // startIndex标签可视区条目的起始索引值
    onRowsRendered=({startIndex})=>{
        this.setState({
            iCurrentIndex:startIndex
        })
    }

    fnscrollToRow=(i)=>{
        this.oRef.current.scrollToRow( i );
    }

    render() {
        let { aCitykey,iCurrentIndex } = this.state;
        return (
            <div className={this.props.sClass}>
                <div className="city_title">
                    <span className="shutoff iconfont icon-shut" onClick={ ()=>this.props.fnSwitch("city_wrap") }></span>
                    <h3>选择城市</h3>
                </div>
        
                <div className="group_con">
                <AutoSizer>
                    {({height, width}) => (
                    <List
                        ref = { this.oRef }
                        width={width}
                        height={height}
                        rowCount={aCitykey.length}
                        // 关联计算高度的方法
                        rowHeight={this.fnCountHeight}
                        rowRenderer={this.rowRenderer}
                        // 当列表滚动时，触发onRowsRendered方法
                        onRowsRendered={ this.onRowsRendered }

                        // 设置滚动到某个索引值的对齐方式
                        scrollToAlignment='start'
                    />
                    )}
                    </AutoSizer>               
                </div>
                <ul className="city_index">
                    {
                        aCitykey.map((item,i)=>(
                            <li className={(iCurrentIndex===i)?"active":""} onClick={ ()=>this.fnscrollToRow(i) } key={item}><span>{(item==='hot')?'热':item.toUpperCase() }</span></li>
                        ))
                    } 
                </ul>
            </div>
        );
    }
}

export default City;