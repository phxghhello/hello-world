import React, { Component } from 'react';

class Info extends Component {
    render() {
        return (
            <div>
                资讯页面
            </div>
        );
    }
}

export default Info;