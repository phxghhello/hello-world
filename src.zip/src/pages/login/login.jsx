import React, { Component } from 'react';
import styles from './login.module.css';
import logo from '../../assets/images/login_title.png';

import axios from 'axios';
import { BASE_URL } from '../../utils';

// 导入formik来处理表单
import { withFormik } from 'formik';
// 导入yup和formik结合使用来做表单验证
import * as Yup from 'yup';


import { Toast } from 'antd-mobile';

const Login = props=>{
    // 获取映射到props上面的属性和方法
    let {
        values,
        handleChange,
        handleSubmit,
        errors,
        handleBlur,
        touched
    } = props;
    //console.log(touched);
    return (
        <div className={ styles.login_wrap }>
            <span className={[styles.back,"iconfont","icon-prev"].join(" ")} onClick={ ()=>props.history.goBack() }></span>
            <div className={ styles.login_title }>
                <img src={logo} alt="login" />
            </div>
            <form className={styles.login_form}>
                <div className={styles.form_group}>
                    <input 
                        autoComplete = 'off'
                        type="text" 
                        placeholder="用户名"
                        value={ values.username } 
                        onChange={ handleChange }
                        // 需要加上name属性，
                        // handleChange方法通过name属性去修改对应的值
                        name="username"
                        // 绑定失去焦点的事件
                        // 绑定这个事件的目的是为了知道表单元件是否操作过
                        // 通过touched对象可以拿到这个是否操作过的布尔值
                        onBlur = { handleBlur }
                    />
                    {
                       (errors.username && touched.username) && <p className={styles.err_tip}>{errors.username}</p>
                    }                    
                    <input 
                        type="password" 
                        placeholder="密码" 
                        value={ values.password }
                        onChange={ handleChange }
                        name="password"
                        onBlur = { handleBlur }
                    />
                    {
                        (errors.password && touched.password) && <p className={[styles.err_tip,styles.err_pass_tip].join(" ")}>{errors.password}</p>
                    }                    
                </div>
                <input 
                    type="button" 
                    value="登 录" 
                    className={styles.input_sub}
                    onClick = { handleSubmit }
                />
            </form>
            <div className={styles.register}>新用户注册</div>
            <div className={styles.findpass}>忘记密码</div>
        </div>
    );
}

let reName = /^\w{5,10}$/;
let rePass = /^\w{5,15}$/;

const Withlogin = withFormik({
    // mapPropsToValues方法是映射组件state中的值到props属性上
    mapPropsToValues:() => ({username:'',password:'' }),
    validationSchema: Yup.object({
        username: Yup.string().matches(reName, '用户名是5到10位的数字字母和下划线').required('请输入用户名'),
        password: Yup.string().matches(rePass, '密码是5到15位的数字字母和下划线').required('请输入密码')
    }),
    handleSubmit: async (values,{props}) => {
       //这里拿不到组件上面的axios，所以用导入的axios
       let oRes = await axios.post(BASE_URL+'/user/login',values);
       console.log(oRes.data);
       let { status,description } = oRes.data;
       if( status===200 ){
            Toast.info('登录成功！',2,()=>{
                localStorage.setItem('haoke_token',oRes.data.body.token);
                props.history.goBack();
            })
       }else{
           Toast.info(description,2)
       }

    }

})(Login);


export default Withlogin;

