import React, { Component } from 'react';
import './detail.css';
import { Carousel,Toast } from 'antd-mobile';
import { BASE_URL } from '../../utils';

import avatar from '../../assets/images/avatar.png';

// 定义房屋配套的文字和图标样式的对应关系
const oSupport = {
    '衣柜':{sClass:'iconfont icon-yigui'},
    '洗衣机':{sClass:'iconfont icon-xiyiji'},
    '空调':{sClass:'iconfont icon-kongtiao'},
    '天然气':{sClass:'iconfont icon-tianranqi'},
    '冰箱':{sClass:'iconfont icon-bingxiang'},
    '电视':{sClass:'iconfont icon-dianshi'},
    '热水器':{sClass:'iconfont icon-reshuiqi'},
    '沙发':{sClass:'iconfont icon-shafa'},
    '暖气':{sClass:'iconfont icon-nuanqi'},
    '宽带':{sClass:'iconfont icon-_huabanfuben'},
}


class detail extends Component {
    // 定义state的简写方式：
    state = {
        // 存储房屋的详细信息
        oHouseData:{
            // 某些数据需要给初始的空值，否则组件初始渲染时
            // 会因为houseImg是一个undefined,所有就拿不到houseImg.length属性而报错
            houseImg:[],
            tags:[],
            oriented:[],
            supporting:[]
        },
        bIsFavorites:false
    }

    componentDidMount(){
        this.fnGetHouseData();
        this.fnCheckFavorites();       
    }

    // 定义一个方法，验证当前的房屋，用户是否已收藏
    fnCheckFavorites=async ()=>{
        let houseCode = this.props.match.params.houseCode;
        let oRes = await this.axios.get('/user/favorites/'+houseCode);
        let { status } = oRes.data;

        if( status === 200 ){
            this.setState({
                bIsFavorites:oRes.data.body.isFavorite
            })
        }
    }

    fnGetHouseData=async ()=>{
        let houseCode = this.props.match.params.houseCode;
        //console.log(houseCode);

        let oRes = await this.axios.get('/houses/'+houseCode);
        //console.log(oRes.data.body);

        this.setState({
            oHouseData:oRes.data.body
        },()=>{
            let BMap = window.BMap;
            let map = new BMap.Map("baidu_map");

            // 通过解构的方式拿出进度和经度和纬度值
            let { longitude,latitude } = this.state.oHouseData.coord;
            // 创建地图实例  
            let point = new BMap.Point(longitude, latitude);
            // 创建点坐标  
            map.centerAndZoom(point, 15);

            //加一个坐标点的红色标注物
            var marker = new BMap.Marker(point);  // 创建标注
            map.addOverlay(marker);

        })
    }

    // 定义收藏当前房屋的方法
    fnSetFavorites=async ()=>{
        let houseCode = this.props.match.params.houseCode;
        let oRes = await this.axios.post('/user/favorites/'+houseCode);
        //console.log( oRes );
        let { status } = oRes.data;
        if( status === 200 ){
            Toast.info('房屋收藏成功！',2,()=>{
                this.fnCheckFavorites(); 
            });
        }else{
            Toast.info('请登录后再收藏房屋。',2);
        }

    }

    // 定义取消收藏的方法
    fnDelFavorites=async ()=>{
        let houseCode = this.props.match.params.houseCode;
        let oRes = await this.axios.delete('/user/favorites/'+houseCode);
        //console.log( oRes );
        let { status } = oRes.data;
        if( status === 200 ){
            Toast.info('取消收藏成功！',2,()=>{
                this.fnCheckFavorites(); 
            });
        }
    }

    /* 
        houseImg: (8) ["/newImg/7bi7en59n.jpg", "/newImg/7bj8mjdob.jpg", "/newImg/7bkn49jja.jpg", "/newImg/7bhe53db6.jpg", "/newImg/7bl4ej6j9.jpg", "/newImg/7bk5h7llh.jpg", "/newImg/7bkle8c74.jpg", "/newImg/7bj41bnpp.jpg"]
        title: "新秀村南区，大三房，小区安静，居家舒适"
        tags: (3) ["近地铁", "新上", "随时看房"]
        price: 5800
        houseCode: "5cc49ec71439630e5b4f6cc4"
        description: "【交通出行】 位于深南大道的东起点，地理位置很好，小区门口有新秀市场，古玩城公交车站。距离新秀地铁站大约300米（来自百度地图）。对于您的出行提供极大便利. 【周边配套】 小区边即为古玩城，古玩玉器茶叶任您挑选，有小吃街，有平安银行，中国银行，工商银行。拥有大型购物超市，华润万家，沃尔玛以及民乐福。买菜可以去新秀肉菜市场。可以满足您平时生活的各种需求。还拥有东湖公园与罗湖体育公园 【小区介绍】 小区边即为古玩城，古玩玉器茶叶任您挑选，有小吃街，有平安银行，中国银行，工商银行。拥有大型购物超市，华润万家，沃尔玛以及民乐福。买菜可以去新秀肉菜市场。可以满足您平时生活的各种需求。还拥有东湖公园与罗湖体育公园"
        roomType: "三室"
        oriented: ["南"]
        floor: "高楼层"
        community: "新秀村南区"
        coord: {latitude: "22.551884294531", longitude: "114.15060200531"}
        supporting: (6) ["衣柜", "洗衣机", "空调", "天然气", "冰箱", "宽带"]
        size: 104
    */

    render() {
        let { oHouseData,bIsFavorites } = this.state;
        return (
            <div>
                <span className="detail_back iconfont icon-prev" onClick={ ()=>this.props.history.goBack() }></span>
    
                <div className="detail_slide_con">
                    {
                        oHouseData.houseImg.length > 0 && <Carousel
                        autoplay={true}
                        infinite
                        >
                        {oHouseData.houseImg.map((item,i) => (
                            <a
                            key={i}
                            href="http://www.itcast.cn"
                            style={{ display: 'inline-block', width: '100%', height:'10.375rem' }}
                            >
                            <img
                                src={BASE_URL+item}
                                alt=""
                                style={{ width: '100%', verticalAlign: 'top' }}
                            />
                            </a>
                        ))}
                        </Carousel>
                    }
                </div>

                <div className="detail_info">
                    <div className="detail_more">
                        <h3>{ oHouseData.title }</h3>
                        <div className="detail_tag">
                            {
                                oHouseData.tags.map((item,i)=>(
                                     <span className={"tag tag"+i} key={i}>{item}</span>
                                ))
                            }
                        </div>
                    </div>

                    <ul className="detail_more more2">
                        <li>
                            <span>{ oHouseData.price }<em>/月</em></span>
                            <b>租金</b>
                        </li>
                        <li>
                            <span>{oHouseData.roomType}</span>
                            <b>房型</b>
                        </li>
                        <li>
                            <span>{oHouseData.size}平米</span>
                            <b>面积</b>
                        </li>
                    </ul>
                    <ul className="detail_more more3">
                        <li><em>装修：</em>精装</li>
                        <li><em>楼层：</em>{oHouseData.floor}</li>
                        <li><em>朝向：</em>{oHouseData.oriented.join('、')}</li>
                        <li><em>类型：</em>普通住宅</li>
                    </ul>
                </div>

                <div className="detail_info">
                    <h4 className="map_title">{oHouseData.community}</h4>
                    <div className="map_con">
                        <div id="baidu_map" style={{'width':'100%','height':'100%'}}></div>
                    </div>

                    <h3 className="detail_common_title">
                        房屋配套
                    </h3>
                    <ul className="support_list">
                        {
                            oHouseData.supporting.map((item,i)=>(
                                <li key={i}>
                                    <i className={oSupport[item].sClass}></i>
                                    <b>{item}</b>
                                </li>
                            ))
                        }
                        {
                            oHouseData.supporting.length===0 && <div style={{'color':'#999','marginBottom':'10px'}}>暂无房屋配套数据</div>
                        }                       
                    </ul>
                </div>

                <div className="detail_info">
                    <h3 className="detail_common_title">
                        房屋概况
                    </h3>
                    <div className="landlord ">            
                        <div className="lorder">
                            <img src={ avatar } alt="" />
                            <div className="lorder_name">
                                <b>王女士</b>
                                <span><i className="iconfont icon-renzheng"></i> <b>已认证房主</b></span>
                            </div>
                            
                        </div>
                        <span className="send_info">发消息</span>
                    </div>
                    <p className="detail_text">
                        { oHouseData.description || '暂无房屋概况' }
                    </p>
                </div>

                <ul className="down_btns">
                    {
                        bIsFavorites?(<li className="collected" onClick={ this.fnDelFavorites }><i className="iconfont icon-shoucang"></i> 已收藏</li>):(<li className="collect" onClick={ this.fnSetFavorites }><i className="iconfont icon-shoucang"></i> 收藏</li>)
                    }
                    <li>在线咨询</li>  
                    <li className="active"><a href="tel:400-618-4000">电话预约</a></li>  
                </ul>

            </div>
        );
    }
}

export default detail;