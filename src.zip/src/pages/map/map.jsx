import React, { Component } from 'react';
import './map.css';
import store from '../store';

// 导入Toast模块，使用它里面的loading
import { Toast } from 'antd-mobile';

import { BASE_URL } from '../../utils';

import Toptitle from '../../components/toptitle/toptitle';

// 全局环境拿到BMap对象
let BMap = window.BMap;

class Map extends Component {
    constructor(props){
        super(props);
        this.state = {
            oCurrentCity:store.getState(),
            // 存储房屋列表容器标签的样式
            sClass:'houseList',
            // 存储房屋列表的数据
            aHouseList:[]
        }
    }

    componentDidMount(){
        //存储当前地图的缩放级别
        this.level = 11;        

        // 将map绑定在组件的this上，方便组件内其他的方法来调用map对象
        this.map = new BMap.Map("baidu_map");

        // 给地图绑定地图的自定义事件movestart，发生此时候后，将房屋列表关闭
        this.map.addEventListener('movestart',()=>{
            this.setState({
                sClass:'houseList'
            })
        })

        //获取当前城市名称
        let sCurrentCityName = this.state.oCurrentCity.label;

        // 通过地名拿到坐标点（逆地址解析）
        var myGeo = new BMap.Geocoder();      
        // 将地址解析结果显示在地图上，并调整地图视野    
        myGeo.getPoint(sCurrentCityName, point=>{      
            if (point) { 
               
                // 在地图上增加比例尺控件
                this.map.addControl(new BMap.NavigationControl()); 

                // 在地图上增加缩放按钮控件   
                this.map.addControl(new BMap.ScaleControl());
                
                // 调用生成标签的方法
                this.fnAddOverlay(point,this.state.oCurrentCity.value,this.level);

            }      
        }, 
        sCurrentCityName);      

    }

    // 定义方法来在地图上增加文字标注
    fnAddOverlay=async (point,id,level)=>{
        //判断level参数是否有传递，如果有传递，说明是第一次调用
        //如果没有传递，说明是第二次或者第三次调用
        if(level){
            this.level = 11;
        }else if( this.level===11 ){
            this.level = 13;
        }else{
            this.level = 15;
        }

        // 通过传入的中心点和来显示地图
        this.map.centerAndZoom(point, this.level);  

        // 开启loading
        Toast.loading('加载中......');
        let oRes = await this.axios.get('/area/map?id='+id);
        // 关闭loading
        Toast.hide();

        //console.log(oRes.data.body);
        let aHouselist = oRes.data.body;

        // 如果不是第三级别的房屋数据，label的样式是map_label01
        if(this.level!==15){
            aHouselist.forEach(item=>{
                // 根据返回的经纬度值创建一个百度的坐标点
                let point = new BMap.Point(item.coord.longitude,item.coord.latitude);
    
                let opts = {
                    position : point,    // 指定文本标注所在的地理位置
                    offset   : new BMap.Size(-35, -35)    //设置文本偏移量
                }
                let label = new BMap.Label(`<div class='map_label01'>${item.label}<br />${item.count}套</div>`, opts);
                
                label.setStyle({
                    border:'0px',
                    backgroundColor:'transparent'
                });
    
                // 给label绑定点击事件
                label.addEventListener('click',()=>{
                    this.fnRefreshMap(point,item.value)
                })
    
                this.map.addOverlay(label); 
    
            })    
        }else{
            aHouselist.forEach(item=>{
                // 根据返回的经纬度值创建一个百度的坐标点
                let point = new BMap.Point(item.coord.longitude,item.coord.latitude);
    
                let opts = {
                    position : point,    // 指定文本标注所在的地理位置
                    offset   : new BMap.Size(-60, -53)  //设置文本偏移量
                }

                let label = new BMap.Label(`<div class='map_label02'>${item.label}&nbsp;&nbsp;${item.count}套</div>`, opts);
                
                label.setStyle({
                    border:'0px',
                    backgroundColor:'transparent'
                });
    
                // 给label绑定点击事件
                label.addEventListener('click',(e)=>{
                    // 传入点击的房屋对应的id
                    // e事件对象被封装了，需要通过e.changedTouches[0]才能拿到鼠标的位置
                    // e.changedTouches[0] 的值是：{clientX: 198.76171875, clientY: 342.1640625}
                    // console.log(e);

                    // 获取鼠标点击的地方的x轴和y轴的位置
                    // 增加程序的健壮性优化,通过e.changedTouches[0]在某种场景中可能拿不到鼠标位置
                    let iMoveX,iMoveY;                 

                    try{
                        let { clientX,clientY } = e.changedTouches[0];
                         // 计算地图位移的x轴向的位置和y轴向的值
                        iMoveX = window.innerWidth/2 - clientX;
                        iMoveY = window.innerHeight/4 - clientY;
                    }catch(err){
                        let { clientX,clientY } = e;
                         // 计算地图位移的x轴向的位置和y轴向的值
                        iMoveX = window.innerWidth/2 - clientX;
                        iMoveY = window.innerHeight/4 - clientY;
                    }

                    this.fnShowHouseList(item.value,{iMoveX,iMoveY});

                })
    
                this.map.addOverlay(label); 
    
            }) 
        }    

    }
   

    // 定义删除原来的覆盖物，显示新的覆盖物的方法
    fnRefreshMap=(point,id)=>{
        // 清除地图上的覆盖物
        // clearOverlays方法会出现一个报错
        // 解决方法是用定时器包裹这个方法
        setTimeout(()=>{
            this.map.clearOverlays();
        },0);

        // 重新生成地图上的覆盖物
        this.fnAddOverlay(point,id);      
    }

     // 定义从地图下面弹出房屋列表页面的方法
     fnShowHouseList=async (id,oBj)=>{
        // 通过panBy这个方法移动地图
        this.map.panBy(oBj.iMoveX,oBj.iMoveY);

        Toast.loading('加载中......');

        // 使用/houses接口，传入地区id，请求房屋的列表数据
        let oRes = await this.axios.get('/houses?cityId='+id);

        // 关闭loading
        Toast.hide()
        //console.log(oRes.data.body.list);

        this.setState({
            sClass:'houseList houseListShow',
            aHouseList:oRes.data.body.list
        })
    }


    render() {
        let { sClass,aHouseList } = this.state;
        return (
            <div>
                <Toptitle title="地图找房" history={ this.props.history } />
                <div className="map_com" >
                   <div id="baidu_map" style={{'width':'100%','height':'100%'}} ></div>
                </div>
                {/* 
                    有houseList houseListShow两个样式，div的高度就是50%
                    有houseList一个样式，div的高度就是0%
                */}
                <div className={ sClass }>
                    <div className="titleWrap">
                        <h1 className="listTitle">房屋列表</h1>
                        <a className="titleMore" href="/house/list">
                            更多房源
                        </a>
                    </div>

                    {/* 
                        houseImg: "/newImg/7bk77dl9f.jpg"
                        title: "碧海云天二期 3室1厅 18500元"
                        tags: (3) ["近地铁", "新上", "随时看房"]
                        price: 18500
                        desc: "三室/74/南/碧海云天二期"
                        houseCode: "5cc4a0461439630e5b4fc599"               
                    */}
                    <div className="houseItems">
                        {
                            aHouseList.map(item=>(
                                <div className="house" key={ item.houseCode }  onClick={ ()=>this.props.history.push('/detail/'+item.houseCode) }>
                                    <div className="imgWrap">
                                        <img className="img" src={ BASE_URL + item.houseImg } alt="房屋图片" />
                                    </div>
                                    <div className="content">
                                    <h3 className="title">{ item.title }</h3>
                                        <div className="desc">{ item.desc }</div>
                                        <div>
                                            {
                                                item.tags.map((val,i)=>(
                                                    <span className={"tag tag"+i} key={i}>{val}</span>
                                                ))
                                            }
                                        </div>
                                        <div className="price">
                                            <span className="priceNum">{item.price}</span> 元/月
                                        </div>
                                    </div>
                                </div>
                            ))
                        }                        
                    </div>
                </div>
            </div>
        );
    }
}

export default Map;