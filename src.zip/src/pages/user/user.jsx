import React, { Component } from 'react';
import './user.css';
import person from '../../assets/images/avatar02.png';
import join from '../../assets/images/join.png';
import { BASE_URL } from '../../utils';

// 导入对话弹框
import { Modal } from 'antd-mobile';

/* 
{
  "status": 200,
  "description": "请求用户数据成功",
  "body": {
    "avatar": "/img/avatar.png",
    "gender": "1",
    "nickname": "好客_880495",
    "phone": null,
    "id": 5
  }
}
*/

class User extends Component {
    constructor(props){
        super(props);
        this.state = {
            oUserInfo:{},
            bIslogin:false
        }
    }

    componentDidMount(){
        this.fnGetUserInfo();
    }

    fnGetUserInfo=async ()=>{
            let oRes = await this.axios.get('/user')
            let { status } = oRes.data;

            if( status===200){
                this.setState({
                    oUserInfo:oRes.data.body,
                    bIslogin:true
                })
            }  
    }

    fnLogout=()=>{
        // 弹出对话弹框
        Modal.alert('用户退出', '你确认退出吗?', [
            { text: '取消'},
            { text: '确定', onPress: async () =>{
                // 删除本地的token
                localStorage.removeItem('haoke_token');
                let oRes = await this.axios.post('/user/logout');
                //console.log( oRes );
                /* 
                let { status } = oRes.data;
                if( status===200 ){
                    this.setState({
                        oUserInfo:{},
                        bIslogin:false
                    })
                } 
                */
                // 用户退出成功，就需要请求本地的数据
                // 如果token异常，相当于token已失效，也就相当于是退出状态，所以也需要删除本地用户数据
                this.setState({
                    oUserInfo:{},
                    bIslogin:false
                })

            }},
        ])
    }

    render() {
        let { oUserInfo, bIslogin} = this.state;
        return (
        <div className="user_wrap">
            <div className="user_header">
                {
                    bIslogin?(
                        <div className="info_pannel">
                            <img src={BASE_URL + oUserInfo.avatar  } alt="" />
                            <div className="role">{ oUserInfo.nickname }</div>
                            <span className="gologin" onClick={ this.fnLogout }>退出</span>
                        </div>
                    ):(
                        <div className="info_pannel">
                            <img src={person} alt="" />
                            <div className="role">游客</div>
                            <span className="gologin" onClick={()=>this.props.history.push('/login') }>去登录</span>
                        </div>
                    )
                } 
            </div>
            <ul className="opt_list">
                <li>
                    <i className="iconfont icon-shoucang"></i>
                    <span>我的收藏</span>
                </li>
                <li>
                    <i className="iconfont icon-home"></i>
                    <span>我的出租</span>
                </li>
                <li>
                    <i className="iconfont icon-shijian"></i>
                    <span>看房记录</span>
                </li>
                <li>
                    <i className="iconfont icon-fangdong"></i>
                    <span>成为房主</span>
                </li>
                <li>
                    <i className="iconfont icon-wode"></i>
                    <span>个人资料</span>
                </li>
                <li>
                    <i className="iconfont icon-kefu"></i>
                    <span>联系我们</span>
                </li>
            </ul>
            <div className="join">
                <img src={ join } alt="" />
            </div>
        </div>
        );
    }
}

export default User;

/* 
"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJJRCI6NSwiaWF0IjoxNTg2MjQ4MDU4LCJleHAiOjE1ODYyNjI0NTh9.xk1z9W48-GB5TTGDhvPokuIYoDv4-UhwyMiXJv1_jgk"

*/