import React, { Component } from 'react';
import Toptitle from '../../components/toptitle/toptitle';
import { BASE_URL } from '../../utils';
import './rentlist.css';

/* 
    {
        desc: "一室/70/东南/石园北区"
        houseCode: "8c74be02-f414-e660"
        houseImg: "/uploads/upload_dda0a4f0d845d3d332cdf7c5256e99ff.jpg"
        price: 2500
        tags: ["近地铁"]
        title: "石园北区 店铺招租"
    }
*/

class Rentlist extends Component {
    state = {
        aHouseList:[]
    }

    componentDidMount(){
        this.fnGetHouseList()
    }

    fnGetHouseList=async ()=>{
        let oRes = await this.axios.get('/user/houses');
        //console.log( oRes );
        this.setState({
            aHouseList:oRes.data.body
        })
    }

    render() {
        let { aHouseList } = this.state;
        return (
            <div>
                <Toptitle title="发布房源列表" history={ this.props.history } />                
                <div className="rent_list_con">
                {
                    aHouseList.map(item=>(
                        <div className="house_wrap" onClick={ ()=>this.props.history.push('/detail/'+item.houseCode) }  key={ item.houseCode }>
                                <div className="house_item">
                                    <div className="imgWrap">
                                        <img className="img" src={BASE_URL+item.houseImg} />
                                    </div>
                                    <div className="content">
                                        <h3 className="title">{item.title}</h3>
                                        <div className="desc">{item.desc}</div>
                                        <div>
                                            {
                                                item.tags.map((val,i)=>(
                                                    <span key={i} className={"tag tag"+i}>{val}</span>
                                                ))
                                            }
                                        </div>
                                        <div className="price">
                                            <span className="priceNum">{item.price}</span> 元/月
                                        </div>
                                    </div>
                                </div> 
                            </div>
                           ))
                    }
                </div>
            </div>
        );
    }
}

export default Rentlist;