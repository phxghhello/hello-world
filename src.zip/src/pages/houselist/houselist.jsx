import React, { Component } from 'react';
import './houselist.css';
import { withRouter } from 'react-router-dom';
import Cityswitch from '../../components/cityswitch/cityswitch';
import store from '../store';

import {List,AutoSizer,InfiniteLoader} from 'react-virtualized';

// 导入PickerView组件来显示过滤条件
import { PickerView } from 'antd-mobile';

import { BASE_URL } from '../../utils';

import { Toast } from 'antd-mobile';

import notfound from '../../assets/images/not-found.png'



class TopBar extends Component{
    render(){
        return (
            <div className="list_title">
                <span className="back iconfont icon-prev" onClick={ ()=>this.props.history.goBack() }></span>
                <Cityswitch />
                <i className="iconfont icon-ic-maplocation-o tomap"  onClick={ ()=>this.props.history.push('/map') }></i>
            </div> 
        )
    }
}

class FilterBar extends Component{
    constructor(props){
        super(props);
        this.state = {
            // 此变量控制PickerView弹框的显示和隐藏
            bShowPickerView:false,
            // 此变量控制tags弹框的显示和隐藏
            bShowTags:false,
            // 定义一个数组变量来列表渲染出过滤条
            aFilterData:[
                {title:'区域',type:'area'},
                {title:'方式',type:'mode'},
                {title:'租金',type:'price'},
                {title:'筛选',type:'more'}
            ],
            // 此变量存储当前点击的按钮的type
            sCurrentType:'',
            // 此变量存储当前城市的数据
            oCurrentCity:store.getState(),
            // 此变量存储所有的过滤数据
            oAllFiterData:{},
            // 此变量存储当前PickerView里面显示的过滤数据
            aNowFiterData:[],
            // 设置当前PickerView的列数
            iCols:1,
            // 此变量存储第二个弹框里面的过滤数据
            aTagsFiterData:[],
            // 此变量存储所有选中的过滤的值
            oAllFilterVal:{
                area:['area','null'],
                mode:['null'],
                price:['null'],
                more:[]
            },
            // 此变量控制过滤条文字是否高亮(变绿色)
            oFilterState:{
                'area':false,
                'mode':false,
                'price':false,
                'more':false
            }
        }

        this.unsubscribe = store.subscribe(this.fnStoreChange);

    }

    fnStoreChange=()=>{
       this.setState({
            oCurrentCity:store.getState()
       },()=>{
            // 在新的当前城市获取之后，再那这个当前城市id去请求新的过滤数据
            this.fnGetFilterData();
            this.setState({
                oAllFilterVal:{
                    area:['area','null'],
                    mode:['null'],
                    price:['null'],
                    more:[]
                },
                oFilterState:{
                    'area':false,
                    'mode':false,
                    'price':false,
                    'more':false
                }
            })
       })
    }

    componentWillUnmount(){
        this.unsubscribe();
    }

    // 在组件挂载到页面之后，去请求过滤条件数据
    componentDidMount(){
        this.fnGetFilterData()
    }

    fnGetFilterData = async ()=>{
        let sAllFiterData = localStorage.getItem('haoke_filter_data'+this.state.oCurrentCity.value);
        let oAllFiterData = {};
        if( sAllFiterData ){
            oAllFiterData = JSON.parse( sAllFiterData )
        }else{
            let oRes = await this.axios.get('/houses/condition?id='+this.state.oCurrentCity.value);
             //将返回的过滤数据存储到localStorage中
            localStorage.setItem('haoke_filter_data'+this.state.oCurrentCity.value,JSON.stringify( oRes.data.body ))
            oAllFiterData = oRes.data.body;
        }
        
        //console.log(oRes.data.body);
        // 将返回的所有过滤数据存储到state中的oAllFiterData变量中
        this.setState({
            oAllFiterData
        },()=>{
            // 从所有过滤数据中拿出第二个弹框所需要的过滤数据
            let { roomType,oriented,floor,characteristic } = this.state.oAllFiterData;
            this.setState({
                // 将这几个数据拼装成适合列表渲染的数组
                aTagsFiterData:[
                    {title:'户型',data:roomType},
                    {title:'朝向',data:oriented},
                    {title:'楼层',data:floor},
                    {title:'房屋亮点',data:characteristic}
                ]
            })
           
        })
    }


    // 定义方法来显示弹框,同时设置当前PickerView里面显示的过滤数据
    fnShowPop=(sType)=>{
        // 如果点击过滤条前面三个名称
        if(sType!=='more'){
            let aNowFiterData = [];
            let iCols = 1;
            // 从整体的过滤数据中拿出PickerView要切换显示的数据
            let { area,rentType,price,subway } = this.state.oAllFiterData;

            //console.log('rentType',rentType);

            if( sType==='area' ){
                aNowFiterData = [area,subway];
                iCols = 3;
            }else if(sType==='mode'){
                aNowFiterData = rentType;
            }else{
                aNowFiterData = price;
            }

            this.setState({
                bShowPickerView:true,
                bShowTags:false,
                // 同时设置设置当前点击的类型
                sCurrentType:sType,
                // 设置当前PickerView里面显示的过滤数据
                aNowFiterData,
                // 设置当前PickerView的列数
                iCols
            })
        }else{
            this.setState({
                bShowPickerView:false,
                bShowTags:true,
                // 同时设置设置当前点击的类型
                sCurrentType:sType
            })
        }
    }

    // 定义方法来隐藏两个弹框
    fnHidePop=()=>{
        this.setState({
            bShowPickerView:false,
            bShowTags:false,
            // 同时把当前点击的类型设置为空字符串
            sCurrentType:""
        })
    }

    // 定义方法来获取PickerView组件的值
    fnGetPickVal=(val)=>{
        //console.log( val );
        this.setState(state=>{
            let oNowFilterVal = state.oAllFilterVal;
            oNowFilterVal[state.sCurrentType] = val;
            return {
                oAllFilterVal:oNowFilterVal
            }
        },()=>{
            //console.log( this.state.oAllFilterVal );
            // 调用设置过滤条文字状态的方法
            this.fnSetFilterState();
        })
    }

    // 定义方法来获取第二个弹框选中的值
    fnGetTagsVal=(val)=>{
        this.setState(state=>{
            let oNowFilterVal = state.oAllFilterVal;
            // 将more数组完全复制出来
            let aNowMore = [...oNowFilterVal.more];
            let aNewMore = [];
            // 判断oNowFilterVal里面的more对应的数组是否包含传入的val
            if( aNowMore.includes(val) ){
                // 如果包含，就将这个值从数组中过滤掉
                aNewMore = aNowMore.filter(item=>item!==val)
                oNowFilterVal.more = aNewMore;
            }else{
                aNowMore.push( val );
                oNowFilterVal.more = aNowMore;
            }

            return {
                oAllFilterVal:oNowFilterVal
            }
        },()=>{
            // 调用设置过滤条文字状态的方法
            this.fnSetFilterState();
        })
    }

    // 定义一个方法来改oFilterState值从而改变过滤条上面文字的高亮状态
    // 判断oAllFilterVal变量里面没一项是否是初始值，如果是，就将oFilterState变量对应项改成false
    // 否则改成true
    fnSetFilterState=()=>{
        this.setState(state=>{
            let oNowAllFilterVal =  state.oAllFilterVal;
            let oNowFilterState = state.oFilterState;

            if(oNowAllFilterVal.area[0]==='area'&&oNowAllFilterVal.area[1]==='null'){
                oNowFilterState.area = false;
            }else{
                oNowFilterState.area = true;
            }

            if(oNowAllFilterVal.mode[0]==='null'){
                oNowFilterState.mode = false;
            }else{
                oNowFilterState.mode = true;
            }

            if(oNowAllFilterVal.price[0]==='null'){
                oNowFilterState.price = false;
            }else{
                oNowFilterState.price = true;
            }

            if(oNowAllFilterVal.more.length===0){
                oNowFilterState.more = false;
            }else{
                oNowFilterState.more = true;
            }

            return {
                oFilterState:oNowFilterState
            }
        })
    }

    // 定义一个方法来拿到所有选择的过滤条件数据，然后把它处理成我们需要的参数格式
    fnSetParamas=()=>{
        // console.log( this.state.oAllFilterVal );
        this.setState(state=>{
            let oNowAllFilterVal = JSON.parse(JSON.stringify(state.oAllFilterVal));
            let oParmas = {};
            /* 
            现在的数据格式：

            oAllFilterVal:{
                area:['area','null'],  ['area','AREA|acdacb70-3025-74c3','null'],,  ['area','AREA|acdacb70-3025-74c3','AREA|acdacb70-3025-74c3'],
                     ['subway','subway|acdacb70-3025-74c3','null']
                mode:['null'],
                price:['null'],
                more:[]
            }

            需要的数据格式：
            {
                'area':'null' 或者 'area':'AREA|acdacb70-3025-74c3' 或者 'subway':'null'
                 或者 'subway':'subway|acdacb70-3025-74c3'
            }          
            */

            // 先判断oNowAllFilterVal.area数组第三个成员是否存在
            if( oNowAllFilterVal.area[2]===undefined ){
                // 如果不存在，那么这个数组的就是['area','null']或者['subway','null']
                oParmas[oNowAllFilterVal.area[0]] = 'null'
            }else if( oNowAllFilterVal.area[2]==='null' ){
                //如果oNowAllFilterVal.area数组第三个成员是null,那么数组就是['area','AREA|acdacb70-3025-74c3','null']
                // 或者 ['subway','AREA|acdacb70-3025-74c3','null']
                oParmas[oNowAllFilterVal.area[0]] = oNowAllFilterVal.area[1]
            }else{
                // 如果第三个成员不是null，那么数组就是['area','AREA|acdacb70-3025-74c3','AREA|acdacb70-3025-7daf']
                // 或者是 ['subway','蛇口线','AREA|acdacb70-3025-7daf']
                oParmas[oNowAllFilterVal.area[0]] = oNowAllFilterVal.area[2]
            }

            // mode对应的数组的值是：['null'],['true'],['false']
            oParmas.rentType = oNowAllFilterVal.mode[0];

            // price对应的数组的值是：["PRICE|3000"]，要得到里面的数字
            oParmas.price = oNowAllFilterVal.price[0].split('|')[1]

            // more对应的数组里面是一个个的id字符串，将它们用“,”拼接起来成一个大的字符串就可以了
            oParmas.more = oNowAllFilterVal.more.join(',');

            // console.log( oParmas );

            // 调用父组件传入的方法，将参数传出去
            this.props.fnGetHouseList( oParmas );

            return {
                bShowPickerView:false,
                bShowTags:false,
                sCurrentType:''
            }
        })

    }

    render(){
        let {
            bShowPickerView, // 此变量控制PickerView弹框的显示和隐藏
            bShowTags, // 此变量控制tags弹框的显示和隐藏
            aFilterData, // 定义一个数组变量来列表渲染出过滤条
            sCurrentType, // 此变量存储当前点击的按钮的type
            aNowFiterData, // 此变量存储当前PickerView里面显示的过滤数据            
            iCols,// 设置当前PickerView的列数
            aTagsFiterData, // 此变量存储第二个弹框里面的过滤数据
            oAllFilterVal, // 此变量存储所有选中的过滤的值    
            oFilterState // 此变量控制过滤条文字是否高亮(变绿色)         
        } = this.state;

        return (
            // 容器标签可以写成空标签的形式
            <>
                <ul className="filter_list">
                    {
                        aFilterData.map(item=>(
                            <li className={((sCurrentType===item.type)?"current ":"")+((oFilterState[item.type])?"active":"")} key={ item.type } onClick={ ()=>this.fnShowPop(item.type) }>
                                <span>{item.title}</span>
                                <i className="iconfont icon-xialajiantouxiangxia"></i>
                            </li>
                        ))
                    }
                </ul>

                {/* 弹框一的结构及它的背景结构 */}
                <div className={bShowPickerView?"slide_pannel pannel_in":"slide_pannel pannel_out"}>
                    <div className="slide_comp">
                        {/* 嵌入PickerView组件来显示过滤条件 */}
                        <PickerView
                            data = {aNowFiterData}
                            // 设置是否级连，也就是是否显示下一级数据
                            cascade = {true}
                            // 设置列数
                            cols = {iCols}
                            // 给组件绑定onChange事件，将组件的值传给关联的方法
                            onChange = { this.fnGetPickVal }
                            // 定义value属性
                            value={ oAllFilterVal[sCurrentType] }

                        />
                    </div>
                    <div className="slide_btns">
                        <span onClick={ this.fnHidePop }>取消</span>
                        <b onClick={ this.fnSetParamas }>确定</b>
                    </div>
                </div>
                <div className={bShowPickerView?"mask mask_in":"mask mask_out"}  onClick={ this.fnHidePop }></div>

                {/* 弹框二的结构及它的背景结构 */}
                <div className={bShowTags?"tags_pannel tags_pannel_in":"tags_pannel tags_pannel_out"}>
                    <div className="tags_list">
                        {
                            aTagsFiterData.map((item,i)=>(
                                <div key={i}>
                                    <h3>{item.title}</h3>
                                    <div className="ul_wrap">
                                        <ul>
                                            {/* 
                                                通过数组的includes方法，判断oAllFilterVal.more数组中是否包含对应的value值
                                                如果包含，说明是选中的，就使用active样式，这个标签就高亮
                                            */}
                                           {
                                               item.data.map(val=><li className={oAllFilterVal.more.includes(val.value)?"active":""} key={ val.value } onClick={ ()=>this.fnGetTagsVal( val.value ) }>{val.label}</li>)
                                           }
                                        </ul>
                                    </div>
                                </div>
                            ))
                        }
                    </div>
                    <div className="tags_btns">
                        <span onClick={ this.fnHidePop }>取消</span>
                        <b onClick={ this.fnSetParamas }>确定</b>
                    </div>
                </div>    
                <div className={bShowTags?"mask2 mask_in":"mask2 mask_out"} onClick={ this.fnHidePop }></div> 
            </>
        )
    }
}



let WithTopBar = withRouter( TopBar );
class Houselist extends Component {
    constructor(props){
        super(props);
        this.state = {
            aHouselist:[],
            oCurrentCity:store.getState(),
            count:0,
            // 定义一个布尔值来存储当前是否已经加载了房屋数据
            bIsloaded:false
        }

        // 初始的时候在组件上存一个params的属性值
        this.params = {};

        // 订阅数据中心当前城市的修改
        this.unsubscribe = store.subscribe( this.fnStoreChange )
    }

    fnStoreChange=()=>{
        this.setState({
            // 重新获取当前城市的数据
            oCurrentCity:store.getState()
        },()=>{
            // 在获取新的当前城市之后，再去用这个城市id请求房屋列表数据
            this.fnGetHouseList({})
        })
    }

    componentWillUnmount(){
        this.unsubscribe();
    }

    componentDidMount(){
        this.fnGetHouseList({})
    }

    // 定义获取房屋数据的方法
    fnGetHouseList=async (params)=>{
        Toast.loading('加载中......');
        // 将传入的条件存储在this.params上
        this.params = params;
        let oRes = await this.axios.get('/houses',{params:{
            //解构传入的对象，让它成为axios请求时的参数
            ...params,
            cityId:this.state.oCurrentCity.value,
            start:1,
            end:20
        }});
        Toast.hide();
        //console.log(oRes.data.body);
        this.setState({
            aHouselist:oRes.data.body.list,
            count:oRes.data.body.count,
            bIsloaded:true
        },()=>{
            // 更加新的条件返回新的数据之后，让List组件滚动到顶部
            this.list.scrollToRow(0);
        })
    }

    /* 
    {
        houseImg: "/uploads/upload_abd51170076fd67c8d9e15f131484137.png"
        title: "天域香山花园"
        tags: ["近地铁"]
        price: 3000
        desc: "三室/120/南/天御香山花园"
        houseCode: "ea7a1c1c-05b9-b848"   
    }
    */

    rowRenderer=({key,index,style})=>{
        let oHouseData = this.state.aHouselist[index];
        
        if(!oHouseData){
            return <div className="reload" key={key} style={ style }><div>loading....</div></div>
        }

        return (
            <div className="house_wrap" key={key} style={ style }>
                <div className="house_item" onClick={ ()=>this.props.history.push('/detail/'+oHouseData.houseCode) }>
                    <div className="imgWrap">
                        <img className="img" src={ BASE_URL + oHouseData.houseImg  } />
                    </div>
                    <div className="content">
                        <h3 className="title">{oHouseData.title}</h3>
                        <div className="desc">{oHouseData.desc}</div>
                        <div>
                            {
                                oHouseData.tags.map((item,i)=>(
                                    <span key={i} className={"tag tag"+i}>{item}</span>
                                ))
                            }
                        </div>
                        <div className="price">
                            <span className="priceNum">{oHouseData.price}</span> 元/月
                        </div>
                    </div>
            </div>
        </div> 
        )   
    }

    isRowLoaded=({ index })=>{
        return !!this.state.aHouselist[index];
    }

    loadMoreRows=({ startIndex, stopIndex })=>{
        return this.axios.get('/houses',{params:{
            //解构this.params对象，让它成为axios请求时的参数
            ...this.params,
            cityId:this.state.oCurrentCity.value,
            start:startIndex,
            end:stopIndex
        }}).then(dat=>{
            this.setState(state=>{
                // 将返回的数据加到原来的数组中
                let aNowHouseList = [...state.aHouselist,...dat.data.body.list];
                return {
                    aHouselist:aNowHouseList
                }
            })

        })
    }


    render() {
        return (
            <div>
                <WithTopBar />
                <FilterBar fnGetHouseList={ this.fnGetHouseList } />

                <div className="house_list_con">
                
                <InfiniteLoader
                        isRowLoaded={this.isRowLoaded}
                        loadMoreRows={this.loadMoreRows}
                        rowCount={this.state.count}
                >
                {({ onRowsRendered, registerChild }) => (
                <AutoSizer>
                    {({height, width}) => (
                    <List
                        width={width}
                        height={height}
                        onRowsRendered={onRowsRendered}
                        ref={(list)=>{
                            // list参数是List组件传递的一个对象，这个对象就指向List组件对象
                            // 将这个list对象关联到this上面的list对象是为了方便在方法中操作List组件的方法
                            this.list = list;
                            // 通过registerChild方法将list对象给到InfiniteLoader组件以便它操作List组件
                            registerChild(list);
                        }}
                        rowCount={this.state.count}
                        rowHeight={120}
                        rowRenderer={this.rowRenderer}
                    />
                    )}
                </AutoSizer>
                )}
                </InfiniteLoader>
                {
                    (this.state.aHouselist.length===0&&this.state.bIsloaded) &&  <div className="notfound">
                        <img src={notfound} alt="没有数据" />
                        <p>没有找到房源，请你换个搜索条件吧~</p>
                    </div>
                }
                </div>
            </div>
        );
    }
}

export default Houselist;