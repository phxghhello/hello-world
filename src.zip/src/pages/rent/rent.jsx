import React, { Component } from 'react';
import './rent.css';
import Toptitle from '../../components/toptitle/toptitle';
import { InputItem,Picker,List,ImagePicker,TextareaItem,Toast} from 'antd-mobile';
import store from '../store';

// 房屋类型
const roomTypeData = [
    { label: "一室", value: "ROOM|d4a692e4-a177-37fd" },
    { label: "二室", value: "ROOM|d1a00384-5801-d5cd" },
    { label: "三室", value: "ROOM|20903ae0-c7bc-f2e2" },
    { label: "四室", value: "ROOM|ce2a5daa-811d-2f49" },
    { label: "四室+", value: "ROOM|2731c38c-5b19-ff7f" }
  ];
  
  // 朝向：
  const orientedData = [
    { label: "东", value: "ORIEN|141b98bf-1ad0-11e3" },
    { label: "西", value: "ORIEN|103fb3aa-e8b4-de0e" },
    { label: "南", value: "ORIEN|61e99445-e95e-7f37" },
    { label: "北", value: "ORIEN|caa6f80b-b764-c2df" },
    { label: "东南", value: "ORIEN|dfb1b36b-e0d1-0977" },
    { label: "东北", value: "ORIEN|67ac2205-7e0f-c057" },
    { label: "西南", value: "ORIEN|2354e89e-3918-9cef" },
    { label: "西北", value: "ORIEN|80795f1a-e32f-feb9" }
  ];
  
  // 楼层
  const floorData = [
    { label: "高楼层", value: "FLOOR|1" },
    { label: "中楼层", value: "FLOOR|2" },
    { label: "低楼层", value: "FLOOR|3" }
  ];
  
  // 房屋配置
  const oSupport = [
    {key:'衣柜',sClass:'iconfont icon-yigui'},
    {key:'洗衣机',sClass:'iconfont icon-xiyiji'},
    {key:'空调',sClass:'iconfont icon-kongtiao'},
    {key:'天然气',sClass:'iconfont icon-tianranqi'},
    {key:'冰箱',sClass:'iconfont icon-bingxiang'},
    {key:'电视',sClass:'iconfont icon-dianshi'},
    {key:'热水器',sClass:'iconfont icon-reshuiqi'},
    {key:'沙发',sClass:'iconfont icon-shafa'},
    {key:'暖气',sClass:'iconfont icon-nuanqi'},
    {key:'宽带',sClass:'iconfont icon-_huabanfuben'},
  ]

class Rent extends Component {
    state = {
        // 存储搜索框里面输入的内容
        sKey:'',
        // 存储搜索面板的样式
        sClass:'search_pannel_con',
        // 存储小区数据
        communityList:[],
        // 存储选定的小区数据
        oCommunity:{},
        // 存在当前城市
        oCurrentCity:store.getState(),
        // 存储房屋价格：
        price:'',
        // 存储建筑面积
        size:'',
        // 存储户型
        roomType:'',
        // 存储楼层
        floor:'',
        // 存储朝向
        oriented:'',
        // 存储房屋标题
        title:'',
        // 存储上传房屋图片的数组
        aHouseImage:[],
        // 存储房屋配套的数据
        aSupportingList:[],
        // 存储房屋描述
        description:''

    }

    fnShowSearchPannel=()=>{
        this.setState(state=>{
            if(state.sClass==='search_pannel_con'){
                return {
                    sClass:'search_pannel_con pannel_show'
                }
            }else{
                return {
                    sClass:'search_pannel_con'
                }
            }
        })
    }

    // 定义多个输入组件绑定的方法
    fnGetVal=(sName,val)=>{
        this.setState({
            [sName]:val
        })
    }

    fnGetCommunity=async ()=>{
        let oRes = await this.axios.get('/area/community',{params:{
            name:this.state.sKey,
            id:this.state.oCurrentCity.value
        }});
        console.log(oRes.data.body);
        this.setState({
            communityList:oRes.data.body
        })
    }

    fnSetCommunity=(oBj)=>{
        this.setState({
            oCommunity:oBj
        },()=>{
            this.fnShowSearchPannel()
        })
    }

    fnReleaseHouse=async ()=>{
        //console.log( this.state );
        // 先拿到所有需要上传的数据
        let {
            price,// 存储房屋价格
            size,// 存储建筑面积
            roomType, // 存储户型             
            floor,  // 存储楼层             
            oriented, // 存储朝向
            title, // 存储房屋标题             
            aHouseImage,// 存储上传房屋图片的数组            
            aSupportingList,// 存储房屋配套的数据
            description,
            oCommunity // 存储小区的信息的对象
        } = this.state;

        // 先判断用户是否有上传房屋图片
        if( aHouseImage.length===0 ){
            Toast.info('请上传房屋图片',2);
            return;
        }

        // 接着先上传房屋图像
        let oFd = new FormData();
        // 将多个对象数据append到oFd对象中，但是使用同一个名称'file'
        aHouseImage.map(item=>{
            oFd.append('file',item.file);
        });

        let oRes = await this.axios.post('/houses/image',oFd);
        
        let { status } = oRes.data;
        
        // 如果房屋图像上传成功
        if(  status === 200){
             // 上传图片返回的是图片的地址组成的数组，需要将这个数组转化成“|”组成的字符串
            let houseImg = oRes.data.body.join('|');
            let sNowSupporting = aSupportingList.join('|');
            let sNowCommunity = oCommunity.community;

            let oRes2 = await this.axios.post('/user/houses',{
                price,
                size,
                roomType,         
                floor,          
                oriented, 
                title,  
                houseImg,          
                supporting:sNowSupporting,
                description,
                community:sNowCommunity
            })

            let { status } = oRes2.data;
            if( status === 200 ){
                Toast.info('房源发布成功！',2,()=>{
                    this.props.history.push('/rlist');
                })
            }

        }else{
            Toast.info('发布房屋失败，请稍后再试！',2);
        }  
    }

    // 设置aSupportingList的值的方法
    fnSetSupport=(sKey)=>{
        this.setState(state=>{
            let aNowSupportingList = state.aSupportingList;
            if( aNowSupportingList.includes( sKey ) ){
                aNowSupportingList = aNowSupportingList.filter(item=>item!==sKey)
            }else{
                aNowSupportingList.push( sKey );
            }
            return {
                aSupportingList:aNowSupportingList
            }

        })
    }

    render() {
        let { 
            sKey, 
            communityList,
            sClass,
            oCommunity,
            price,// 存储房屋价格
            size,// 存储建筑面积
            roomType, // 存储户型             
            floor,  // 存储楼层             
            oriented, // 存储朝向
            title, // 存储房屋标题             
            aHouseImage,// 存储上传房屋图片的数组            
            aSupportingList,// 存储房屋配套的数据
            description // 存储房屋描述
        } = this.state;
        return (
            <div>
                <Toptitle title="发布房源" history={ this.props.history } />
                <h3 className="rent_title">房源信息</h3>
                <div className="info_con">
                    <div className="select_name_con" onClick={ this.fnShowSearchPannel }>
                        <span className="fl">小区名称</span>                        
                        <i className="iconfont icon-next fr"></i>
                        <b className="fr">{oCommunity.communityName}</b>
                    </div>
                    <InputItem
                        value={ price }
                        placeholder="请输入租金/月"
                        extra="¥/月"
                        onChange={ val=>{ this.fnGetVal('price',val) } }
                    >租金</InputItem>
                    <InputItem
                        placeholder="请输入建筑面积"
                        extra="㎡"
                        value={ size }
                        onChange={ val=>{ this.fnGetVal('size',val) } }
                    >建筑面积</InputItem>
                    <Picker
                        data={roomTypeData}
                        value={[roomType]}
                        onChange={ val=>{ this.fnGetVal('roomType',val[0]) } }
                        title="选择户型"
                        cols={ 1 }
                        extra="请选择"
                    >
                        <List.Item arrow="horizontal">户型</List.Item>
                    </Picker>
                    <Picker
                        value={ [floor]}
                        onChange={ val=>{ this.fnGetVal('floor',val[0]) } }
                        data={floorData}
                        title="选择楼层"
                        cols={ 1 }
                        extra="请选择"
                    >
                        <List.Item arrow="horizontal">所在楼层</List.Item>
                    </Picker>
                    <Picker
                        value={ [oriented] }
                        onChange={ val=>{ this.fnGetVal('oriented',val[0])}}
                        data={orientedData}
                        title="选择朝向"
                        cols={ 1 }
                        extra="请选择"
                    >
                        <List.Item arrow="horizontal">朝向</List.Item>
                    </Picker>
                </div>
                <h3 className="rent_sub_title">房屋标题</h3>
                <div className="info_con">
                    <InputItem
                        value={ title }
                        onChange={ val=>{ this.fnGetVal('title',val) } }
                        placeholder="请输入房屋标题"
                    />
                </div>
                <h3 className="rent_sub_title">房屋图像</h3>
                <div className="info_con">
                    <ImagePicker
                        files={ aHouseImage }
                        onChange={val=>{ this.fnGetVal('aHouseImage',val) } }
                        // 设置多张图像上传
                        multiple = {true}
                    />
                </div>
                <h3 className="rent_sub_title">房屋配套</h3>
                <div className="info_con">
                    <ul className="supporting_list">
                        {
                            oSupport.map((item,i)=>(
                                <li 
                                    key={i} 
                                    className={(aSupportingList.includes(item.key))?"active":""}
                                    onClick={ ()=>this.fnSetSupport(item.key) }
                                >
                                    <i className={ item.sClass }></i>
                                    <b>{ item.key }</b>
                                </li>
                            ))
                        }                        
                    </ul>
                </div>
                <h3 className="rent_sub_title">房屋描述</h3>
                <div className="info_con mb116">
                    <TextareaItem
                        value = { description }
                        onChange={val=>{ this.fnGetVal('description',val) } }
                        rows={5}
                        placeholder="请输入房屋描述信息"
                    />
                </div>
                <div className="down_btn">
                    <span>取消</span>
                    <b onClick={ this.fnReleaseHouse }>确定</b>
                </div>
                
                <div className={sClass}>
                    <div className="search_header">
                        <div className="search_input_con">
                            <InputItem
                                placeholder="请输入关键字"
                                value = { sKey }
                                onChange={ val=>{ this.fnGetVal('sKey',val) } }
                            />
                        </div>
                        {
                            sKey===''?( <div className="search_submit" onClick={ this.fnShowSearchPannel }>取消</div>):( <div className="search_submit" onClick={ this.fnGetCommunity }>确定</div>)
                        }                       
                    </div>
                    <div className="search_list_con">
                        {/* 
                            {
                                area: "AREA|9695ec5f-e42a-675e"
                                areaName: "南山区"
                                city: "AREA|a6649a11-be98-b150"
                                cityName: "深圳"
                                community: "AREA|0e586408-4a81-26ff"
                                communityName: "中海深圳湾畔花园"
                                street: "AREA|fca3ecbb-c8c5-edde"
                                streetName: "白石洲"
                            }                     
                        */}
                        <ul>
                            {
                                communityList.map(item=>(
                                    <li key={item.community} onClick={ ()=>this.fnSetCommunity(item) }>{ item.communityName }</li>
                                ))
                            }                            
                        </ul> 
                    </div>
                </div>


            </div>
        );
    }
}

export default Rent;