import React, { Component } from 'react';
import './home.css';

// 从antd-mobile组件库中导入轮播图组件
import { Carousel } from 'antd-mobile';

import { BASE_URL } from '../../utils';

//导入withRouter高阶组件，它可以包裹组件，然组件拥有路由属性
import { Link,withRouter } from 'react-router-dom';

// 导入数据中心
import store from '../store';


import Cityswitch from '../../components/cityswitch/cityswitch';



class SearchBar extends Component{
    componentDidMount(){
        // 去本地缓存中获取当前城市数据
        let sCurrentCityObj = sessionStorage.getItem('haoke_current_city');
        // 如果有当前城市数据
        if(sCurrentCityObj){
            let oCurrentCityObj = JSON.parse( sCurrentCityObj );
    
            // 同时将当前城市存储到数据中心
            store.dispatch({
                type:'change_current_city',
                value:oCurrentCityObj
            })

        }else{

            // 使用百度地图来定位当前城市
            // BMap是百度的js中定义的一个对象，直接引用是拿不到的
            // 可以通过 window.BMap 拿到这个对象
            let BMap = window.BMap;

        /*  
        function myFun(result){
                var cityName = result.name;
                alert("当前定位城市:"+cityName);
            }
            var myCity = new BMap.LocalCity();
            myCity.get(myFun); 
            */

            // 上面的代码可以简化成下面的写法：       
            var myCity = new BMap.LocalCity();
            myCity.get(async result=>{
                let cityName = result.name;            
                //alert("当前定位城市:"+cityName);

                // 将定位到的城市名称传到一个接口中，来检验这个城市是否在公司的业务范围内
                // 如果再公司的业务范围内，就返回这个城市名称，如果不在，就返回上海的城市名称
                let oRes = await this.axios.get('/area/info?name='+cityName);
                //console.log(oRes.data.body);  //{label: "上海", value: "AREA|dbf46d32-7e76-1196"}

                // 将当前城市的数据存储本地，将数据存储在sessionStorage中
                sessionStorage.setItem('haoke_current_city',JSON.stringify( oRes.data.body ))

                // 同时将当前城市存储到数据中心
                store.dispatch({
                    type:'change_current_city',
                    value:oRes.data.body
                })

            }); 
        }
    }



    render(){
        return (
            <div className="search_bar">
                <Cityswitch />
                <i className="iconfont icon-ic-maplocation-o tomap" onClick={ ()=>this.props.history.push('/map') }></i>
            </div>
        )
    }
}



// 定义一个轮播图组件
class Slide extends Component{
    // 在constructor里面定义state的值可以简写成直接定义state的值
    state = {
        data:[]
    }

    // 在组件挂载到页面之后，去请求轮播图的数据
    componentDidMount(){
        this.fnGetData()        
    }

    fnGetData = async ()=>{
        let oRes = await this.axios.get('http://183.237.67.218:3001/home/swiper');
        //console.log(oRes);
        this.setState({
            data:oRes.data.body
        });        
    }

    render(){
        let { data } = this.state;
        return (
            // 当数据回来后，length会大于0，这个时候才渲染轮播图
            // 数据没回来，就不渲染轮播图
            <div className="slide_con">
                {
                    data.length > 0 && <Carousel
                    autoplay={true}
                    infinite
                    >
                    {this.state.data.map(item => (
                        <a
                        key={item.id}
                        href="http://www.itcast.cn"
                        style={{ display: 'inline-block', width: '100%', height:'10.6rem' }}
                        >
                        <img
                            src={BASE_URL+item.imgSrc}
                            alt=""
                            style={{ width: '100%', verticalAlign: 'top' }}
                        />
                        </a>
                    ))}
                </Carousel>
                }                
            </div>
        )
    }
}


// 定义一个菜单组件
function Menu(){
    return (
        <ul className="menu_con">
            <li>
                <Link to="/layout/houselist"><i className="iconfont icon-zufang1"></i></Link>
                <h4>整租</h4>
            </li>
            <li>
                <Link to="/layout/houselist"><i className="iconfont icon-usergroup"></i></Link>
                <h4>合租</h4>
            </li>
            <li>
                <Link to="/map"><i className="iconfont icon-ic-maplocation-o"></i></Link>
                <h4>地图找房</h4>
            </li>
            <li>
                <Link to="/rent"><i className="iconfont icon-zufang"></i></Link>
                <h4>去出租</h4>
            </li>
        </ul>
    )
}


// 定义租房小组的组件
class Group extends Component{
    state={
        data:[]
    }

    componentDidMount(){
        this.fnGetData();
    }

    fnGetData = async ()=>{
        let oRes = await this.axios.get('/home/groups?area=AREA%7C88cff55c-aaa4-e2e0');
        //console.log(oRes);
        this.setState({
            data:oRes.data.body
        })
    }

    render(){
        let {data} = this.state;
        return (
            <div className="model2">
            <div className="title_con">
                <h3>租房小组</h3>
                <Link to="/" className="iconfont icon-next"></Link>
            </div>
            <ul className="house_list">
                {
                    data.map(item=>(
                         <li key={item.id}>
                            <p className="fl">{item.title}</p>
                            <img src={BASE_URL + item.imgSrc} alt="" className="fr" />
                            <span className="fl">{item.desc}</span>
                        </li> 
                    ))
                }                             
            </ul>
        </div>
        )
    }
}

class News extends Component{
    state={
        data:[]
    }

    componentDidMount(){
        this.fnGetData();
    }

    fnGetData = async ()=>{
        let oRes = await this.axios.get('/home/news?area=AREA%7C88cff55c-aaa4-e2e0');
        //console.log(oRes);
        this.setState({
            data:oRes.data.body
        })
    }

    render(){
        let {data} = this.state;
        return (
            <div className="model mb120">
                <div className="title_con">
                    <h3>最新资讯</h3>
                    <Link to="/" className="iconfont icon-next"></Link>
                </div>
                <ul className="list">
                    {
                        data.map(item=>(
                             <li key={ item.id }>
                                <a href="#"><img src={BASE_URL+item.imgSrc} alt="" /></a>
                                <div className="detail_list">
                                    <h4>{item.title}</h4>
                                    <div className="detail">
                                        <span>{item.from}</span>
                                        <em>{item.date}</em>
                                    </div>
                                </div>
                            </li>
                        ))
                    }
                   
                </ul>
            </div>
        )
    }
}


//使用withRouter高阶组件将SearchBar组件包裹，让它拥有路由属性
let WithSearchBar = withRouter( SearchBar );

class Home extends Component {
    render() {
        return (
            <div>
                <Slide />
                <Menu />
                <Group />
                <News />
                <WithSearchBar />
            </div>
        );
    }
}

export default Home;