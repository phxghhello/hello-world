let BASE_URL = 'http://183.237.67.218:3001';

export { BASE_URL };