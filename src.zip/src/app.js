import React, { Component,Suspense,lazy } from 'react';
import { HashRouter,Route,Redirect,Switch,withRouter} from 'react-router-dom';

import Layout from './pages/layout/layout';

const Map = lazy(()=>import('./pages/map/map'));
const Detail = lazy(()=>import('./pages/detail/detail'));
const Login = lazy(()=>import('./pages/login/login'));
const Rent = lazy(()=>import('./pages/rent/rent'));
const Rlist = lazy(()=>import('./pages/rentlist/rentlist'));


let Withrent = withRouter(Rent);
let Withlogin = withRouter(Login);

class App extends Component {
    render() {
        return (
            <HashRouter>
                <Suspense fallback={<div>Loading...</div>}>
                <Switch>
                    <Route path="/layout" component={ Layout } />
                    <Route path="/map" component={ Map } />
                    <Route path="/login" component={ Login } />
                    {/* 
                        路由拦截，通过条件加载不同的组件
                    */}
                    <Route path="/rent" render={()=>{
                        let sToken = localStorage.getItem('haoke_token');
                        if(sToken){
                            return <Withrent />
                        }else{
                            return <Withlogin />
                        }
                    }} />
                    <Route path="/rlist" component={ Rlist } />
                    <Route path="/detail/:houseCode" component={ Detail } />
                    <Redirect exact from="/" to="/layout" />
                </Switch>
                </Suspense>
            </HashRouter>
        );
    }
}

export default App;