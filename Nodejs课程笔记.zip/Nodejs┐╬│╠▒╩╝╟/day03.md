# 01-nodejs搭建静态资源服务器

* ==本小节核心重点==
  * 1.html中所有外部资源路径都会变成网络请求
    * 服务器需要根据请求路径响应返回对应的文件
  * 2.静态资源(图片、文件、音视频)一般使用路径拼接的方式来处理
    * 服务端可以直接拼接url来响应对应资源，简化代码

## 1.1-nodejs搭建静态资源服务器01

![1571414311893](day02.assets/1571414311893.png)

```javascript
/*WEB开发特点1：html中所有外部资源路径都会变成网络请求
*/

//1.导入模块
//http模块
const http = require('http');
//fs文件模块
const fs = require('fs');
//path路径模块
const path = require('path');


//2.创建服务器
let server = http.createServer((req, res) => {
    console.log(req.url);

    if (req.url == '/') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www',  'index.html'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else if (req.url == '/resource/css/index.css') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www','resource', 'css', 'index.css'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else if (req.url == '/resource/images/01.gif') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www','resource', 'images', '01.gif'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else if (req.url == '/resource/images/01.jpg') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www','resource', 'images', '01.jpg'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else if (req.url == '/resource/video.mp4') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www','resource', 'video.mp4'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else if (req.url == '/resource/favicon.ico') {
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname, 'www','resource', 'favicon.ico'), (err, data) => {
            if (err) {
                throw err;//如果读取失败，抛出异常
            } else {
                res.end(data);//如果读成功，响应给客户端
            }
        });
    } else {
        res.end('404 not found');
    };
});

//3.开启服务器
server.listen(3000, () => {
    console.log('服务器启动成功');
});
```



## 1.2-nodejs搭建静态资源服务器02

```javascript
/*WEB开发特点2：静态资源(图片、文件、音视频)一般使用路径拼接的方式来处理
*/

//1.导入模块
//http模块
const http = require('http');
//fs文件模块
const fs = require('fs');
//path路径模块
const path = require('path');


//2.创建服务器
let server = http.createServer((req,res)=>{
    console.log(req.url);
    
    if(req.url == '/'){
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname,'www','index.html'),(err,data)=>{
            if(err){
                throw err;//如果读取失败，抛出异常
            }else{
                res.end(data);//如果读成功，响应给客户端
            }
        });
    }else if(req.url.indexOf('/resource') == 0){//只要路径以/resource开头，直接拼接返回
        //读取文件响应给客户端
        fs.readFile(path.join(__dirname,'www',req.url),(err,data)=>{
            if(err){
                throw err;//如果读取失败，抛出异常
            }else{
                res.end(data);//如果读成功，响应给客户端
            }
        });
    }else{
        res.end('404 not found');
    };
});

//3.开启服务器
server.listen(3000,()=>{

    console.log('服务器启动成功');
});
```



# 02-nodejs接收get请求与post请求

## 1.1-Nodejs获取get请求参数



* 在http协议中，一个完整的url路径如下图
  * 通过下图我们可以得知，get请求的参数是直接在url路径中显示。
  * get的请求参数在path资源路径的后面添加，以`?`表示参数的开始，以`key=value`表示参数的键值对，多个参数以`&`符号分割

  * hash部分表示的是资源定位符（滚动网页可视区域），由浏览器自动解析处理，它的作用是跳转到对应id的标签的位置

![1571414438199](day02.assets/1571414438199.png)



```javascript
//1.导入模块
const http = require('http');
//url模块：解析url路径得到url协议中的每一部分
const url = require('url');

//2.创建服务器
let server = http.createServer((req,res)=>{
    //req.url:获取整个请求url  包含路径和参数
    console.log(req.url);
    //decodeURI():了解即可，默认情况下url中的中文会进行URI编码，使用decodeURI解码可以得到中文
    console.log(decodeURI(req.url));

    /*1.使用url模块解析get请求 
    第一个参数：要解析的url
    第二个参数: 布尔类型  true：推荐使用，得到的参数是一个对象   false：得到参数是字符串
    返回值：对象类型：将url中的每一部分作为对象的属性
     */
    let urlObjc = url.parse(req.url,true);
    console.log(urlObjc);

    //2.获取请求的路径
    let urlPath = urlObjc.pathname;
    console.log(urlPath);
    //3.获取请求的参数
    let query = urlObjc.query;
    console.log(query);

    //响应客户端请求
    //服务端不能直接响应js对象，需要转成json对象（后台具有跨平台性，不是只为前端服务）
    res.end(JSON.stringify({
        code:10000,
        list:[10,20,30]
    }));
   /*
   {
  protocol: null,//协议名
  slashes: null,//表示 //到第一个/之间都是host
  auth: null,//认证
  host: null,//主机名+ 端口号  hosetname+port
  port: null,//端口号
  hostname: null,//主机名  ip地址
  hash: null,//资源定位符
  search: '?name=OldFe&age=18',
  query: { name: 'OldFe', age: '18' },//get请求的参数对象
  pathname: '/getRequest',//路径
  path: '/getRequest?name=OldFe&age=18',//路径+请求参数
  href: '/getRequest?name=OldFe&age=18' }
   */
   //console.log(urlObjc);

});

//3.开启服务器
server.listen(3000,()=>{
    console.log('success');
});
```



## 1.2-Nodejs获取post请求参数



* post请求特点
  * post请求的参数是在请求体中，无法使用get的方式来接收post请求的参数
  * post请求的参数无法一次获取，有可能是多次 原因：post可以提交大数据，而宽带有网络限制



```javascript


//1.导入模块
const http = require('http');
//解析post请求的参数
var querystring = require('querystring');

//2.创建服务器
let server = http.createServer((req,res)=>{
    console.log(req.url + ':' + req.method);
        /*nodejs接收post请求参数
         * 1.post请求的参数是在请求体中，无法使用get的方式来接收post请求的参数
         * 2.post请求的特点：post请求的参数无法一次获取，有可能是多次 原因：post可以提交大数据，而宽带有网络限制
         */
        //nodejs接收post请求参数的流程
        
        //1.给req对象注册一个data事件：表示开始接收post请求参数
        //客户端没发送一次数据该方法都会执行一次，回调函数的参数就是本次接收到的数据（数据流）
        //接受的次数不固定：取决于数据的大小和你的宽带的网速
        let postData = "";
        req.on('data', function (chuck) {
            postData += chuck;
        });
        //2.给req对象注册一个end事件，表示本次post数据发送完毕
        req.on('end', function () {
            //当客户端本次post请求数据发送完毕之后，会执行这个函数
            console.log(postData);
            //3.解析post参数得到参数对象
            //使用querystring模块来解析post请求的参数
            var postObjc =  querystring.parse(postData);
            console.log(postObjc);
            //响应客户端
            res.end(JSON.stringify(postObjc));
        });
});



server.listen(3000, ()=>{
    console.log('success');
});


```



* 使用form标签默认提交事件模拟ajax发送post请求

```html

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form id="form" action="http://127.0.0.1:3000/register" method="POST" enctype="application/x-www-form-urlencoded">
        <div>
            <input type="text" placeholder="用户名" name = "username">
        </div>
        <div>
            <lable><input type="radio" value="男" name = "gender" checked>男</lable>
            <lable><input type="radio" value="女" name = "gender">女</lable>
        </div>
        <div>
            <input type="password" placeholder="密码" name="password">
        </div>
        <div><input type="submit"></div>
    </form>
</body>
</html>
```



# ==03-Nodejs使用第三方模块流程(以爬虫模块Crawler为例)==

## 1.1-npm与cnpm介绍

* 1.npm
  * 全称node package manager
  * 官方推出的包管理工具
  * 不需要额外安装，安装node之后自带
  * 因为服务器不在国内，所以有时候安装特别慢，甚至无法成功
* 2.cnpm
  * 全称china node package manager
  * 非官方推出的包管理工具
  * 需要额外安装：`npm install -g cnpm --registry=https://registry.npm.taobao.org`
  * 国内安装特别快，不需要翻墙（如果特殊情况无法安装，也可使用npm）
  * 安装成功之后，通过`cnpm -v`查看



## 1.2-npm使用流程

* 1.初始化：在当前nodejs项目中执行终端命名: `npm init -y`
  * 作用：生成一个`pachage.json`文件，帮你记录当前项目安装了哪些第三方模块及对应的版本号
* 2.安装：在当前nodejs项目中执行终端命名: `npm install 模块名`
  * 安装之后，你的项目目录会新增两个文件`node_modules`与`package-lock.json`
    * `node_modules`:npm会自动将所有的第三方模块放入这个文件夹中。类似于前端的`lib文件夹`
    * `package-lock.json`：npm会自动记录第三方模块的下载地址，下一次安装或更新的时候直接从这个地址下载，速度更快(只是影响以后更新速度，不影响开发)
    * `pachage.json`:帮你记录当前项目安装了哪些第三方模块及对应的版本号
* 3.注意点：
  * (1)使用npm`文件夹路径`不能有中文
  * (2)使用cnpm安装第三方模块得时候需要添加 `--save`命令。  
    * 示例
      * npm安装crawler : `npm install crawler`
        * npm会自动执行`--save`，将下载路径保存到`package-lock.json`文件中
      * cnpm安装crawler : `cnpm install crawler --save`
  * (3)优先建议使用npm命令来安装。 如果网速很慢导致无法安装第三方模块，建议使用以下两种方式
    * a.优先建议 ： 更改npm镜像源为淘宝服务器
      * `npm config set registry https://registry.npm.taobao.org/`
      * 查看当前npm得镜像源：`npm config list  `
    * b.使用cnpm命令来安装第三方模块



## 1.3-第三方模块使用流程（适合所有第三方模块）

* 1.进npm官网搜索模块:https://www.npmjs.com/
* 2.按照官方文档要求安装模块`npm install 模块名`
* 3.复制粘贴官网代码(别人作者提前写好的)



### 爬虫实战

* crawler爬取网页

```javascript
//1.导入模块
var Crawler = require("crawler");

//2.创建爬虫对象
var c = new Crawler({
    maxConnections : 10,
    // This will be called for each crawled page
    callback : function (error, res, done) {
        //爬好之后会执行这个回调函数
        if(error){
            console.log(error);
        }else{
            //将爬好的数据赋值给juqery对象
            var $ = res.$;
            // $ is Cheerio by default
            //a lean implementation of core jQuery designed specifically for the server
            console.log($("html").html());
            //使用jquery的语法来解析页面
            console.log($('#lg>img').attr('src'));  
        }
        done();
    }
});
 
// Queue just one URL, with default callback
//3.开始爬虫
c.queue('http://www.baidu.com');
```



* crawler爬取文件



```javascript
var Crawler = require("crawler");
var fs = require('fs');
 
var c = new Crawler({
    encoding:null,
    jQuery:false,// set false to suppress warning message.
    callback:function(err, res, done){
        if(err){
            console.error(err.stack);
        }else{
            //将爬取好的文件通过fs模块写入文件
            fs.createWriteStream(res.options.filename).write(res.body);
        }
        
        done();
    }
});
 
//绝大多数网站，都有反爬机制。只有小众网站没有
//浏览器可以下载，但是服务端爬虫无效。反爬：检测你这个请求是通过浏览器发出来，还是服务端（解决方案：让服务端伪装成浏览器来发这个请求）
c.queue({
    url:"http://upos-hz-mirrorks3u.acgvideo.com/upgcxcode/75/11/112251175/112251175-1-6.mp4?e=ig8euxZM2rNcNbdlhoNvNC8BqJIzNbfq99M=&uipk=5&nbs=1&deadline=1571396695&gen=playurl&os=ks3u&oi=2005998532&trid=a4c624adafe64ababb2a851334eaf87eh&platform=html5&upsig=2a29cd105837278e3b4c92181fe3eb59&uparams=e,uipk,nbs,deadline,gen,os,oi,trid,platform&mid=0",
    filename:"./video/11111.mp4",//写入文件名 默认在根目录
    headers:{'User-Agent': 'requests'}//让服务端伪装成客户端
});
```