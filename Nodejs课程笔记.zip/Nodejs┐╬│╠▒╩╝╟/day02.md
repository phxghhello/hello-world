# ==01-nodejs核心模块==

## 1.1-fs文件模块(读写文件)

### 1.1.1-readFile读取文件

```javascript
//1.导入文件模块
const fs = require('fs');

//2.读取文件

/**
 * 第一个参数：文件路径
 * 第二个参数：编码格式 （可选参数，默认为buffer二进制）
 * 第三个参数：读取回调操作（异步操作）
    * err:如果读取成功，err为null,  否则读取失败（一般文件路径错误或者找不到文件）
    * data:读取到的数据
*/
fs.readFile('./data/aaa.txt','utf-8',(err,data)=>{
    
    if(err){
        console.log(err);
        //抛出异常，throw的作用就是让node程序终止运行，方便调试
        throw err;
    }else{
        console.log(data);
    };
});

console.log('11111');

//3.同步读取文件(了解即可，几乎不用,一般在异步的api后面加上Sync就是同步)

let data = fs.readFileSync('./data/aaa.txt','utf-8');
console.log(data);

console.log('2222');
```



### 1.1.2-writeFile写入文件



```javascript
//1.导入文件模块
const fs = require('fs');

//2.写文件

/**
 * 第一个参数：文件路径
 * 第二个参数：要写入的数据
 * 第三个参数：文件编码 默认utf-8
 * 第四个参数： 异步回调函数
    * err:  如果成功，err为null.否则读取失败
 */
fs.writeFile('./data/bbb.txt','黑马程序员','utf-8',(err)=>{
    if(err){
        throw err;
    }else{
        console.log('写入成功');
    };
});
```



## 1.2-同步与异步区别



* 1.同步会阻塞线程，异步不会

* 2.同步有序执行，异步无序执行

* 3.同步没有回调函数，异步有回调函数

  

```javascript
//1.导入模块
const fs = require('fs');

/*js从上往下解析代码流程
    1.判断是同步还是异步
    2.如果是同步，则立即执行
    3.如果是异步，则不执行，而是放入事件循环中(Event Loop)
    4.所有代码解析完毕之后，开始执行事件循环中的异步代码

*/

/*异步操作
1.不会阻塞线程（性能高）
2.无序执行
3.有回调函数 
 */

//异步操作
// console.log('55555555');
// fs.readFile('./data/aaa.txt','utf8',(err,data)=>{
//     console.log('1111111');
    
//     if(err){
//         throw err;
//     }else{
//         // console.log(data); 
//     };
// });


// console.log('666666');
// fs.readFile('./data/aaa.txt','utf8',(err,data)=>{
//     console.log('222222');
    
//     if(err){
//         throw err;
//     }else{
//         // console.log(data); 
//     };
// });

// console.log('777777');
// fs.readFile('./data/aaa.txt','utf8',(err,data)=>{
//     console.log('333333');
    
//     if(err){
//         throw err;
//     }else{
//         // console.log(data); 
//     };
// });

// console.log('8888888');
// fs.readFile('./data/aaa.txt','utf8',(err,data)=>{
//     console.log('4444444');
    
//     if(err){
//         throw err;
//     }else{
//         // console.log(data); 
//     };
// });


//同步操作
/* 1.会阻塞线程（性能低）
    2.有序执行
    3.没有回调函数

 */
let data1 = fs.readFileSync('./data/aaa.txt','utf8');
console.log(data1);
console.log('11111');

let data2 = fs.readFileSync('./data/aaa.txt','utf8');
console.log('22222');
console.log(data2);

let data3 = fs.readFileSync('./data/aaa.txt','utf8');
console.log('33333');
console.log(data3);


let data4 = fs.readFileSync('./data/aaa.txt','utf8');
console.log('44444');
console.log(data4);

```



经典面试题

![1571384852468](day01.assets/1571384852468.png)






## 1.3-path路径模块

### 1.3.1-nodejs中的相对路径介绍

* node中的相对路径： ./  不是相对于当前文件所在路径，而是相对于执行node命名的文件夹路径

  在服务端开发中，一般不要使用相对路径，而使用绝对路径

* 解决方案：在nodejs中，每一个js文件都有两个全局属性，它可以帮助我们获取到文件的绝对路径

  * __filename:当前js文件所在目录的绝对路径

  * __dirmame:当前js文件的绝对路径



```javascript
//1.导入文件模块

const fs = require('fs');

//2.读取文件


/*a.注意点： node中的相对路径： ./  不是相对于当前文件所在路径，而是相对于执行node命名的文件夹路径
在服务端开发中，一般不要使用相对路径，而使用绝对路径
  b.解决方案：在nodejs中，每一个js文件都有两个全局属性，它可以帮助我们获取到文件的绝对路径
    __filename:当前js文件所在目录的绝对路径
    __filema,e:当前js文件的绝对路径
*/
console.log(__dirname);
console.log(__filename);

/*2.如果想要获取当前文件夹下其他文件绝对路径，可以使用 __dirname属性来拼接
*/

var path = __dirname + '/aaa.txt';
console.log(path);

fs.readFile(path,'utf-8',(err,data)=>{
    
    if(err){
        console.log(err);
        //抛出异常，throw的作用就是让node程序终止运行，方便调试
        throw err;
    }else{
        console.log(data);
    };
});


```

### 1.3.2-path路径模块拼接路径

```javascript
//1.导入路径模块
const path = require('path');

//2.合并路径

/*使用path模块拼接文件路径与  使用 '+'连接符拼接的好处
    1.会自动帮我们正确添加路径分隔符  '/',我们无需手动添加
    2.当我们路径格式拼接错误的时候，能自动帮我们转换正确的格式

*/

// path.join(路径1，路径2，路径3，……………………)
let filePath = path.join(__dirname,'aaa.txt');
console.log(filePath);

console.log(__dirname + '/aaa.txt');

let path1 = path.join(__dirname,'bbb','ccc.txt');
console.log(path1);

//获取上级目录   path.dirname(文件路径)
let path2 = path.dirname(path1);
console.log(path2);

let path3 = path.dirname(path2);
console.log(path3);

let path4 = path.dirname(path3);
console.log(path4);

```

## ==1.4-http模块(搭建服务器)==

### 1.4.1-http模块搭建服务器

```javascript
//1.导入模块

const http = require('http');

//2.创建服务器
/*createServer 相当于安装了 phpStudy中的Apache
    参数：回调函数
        req:request  客户端请求的数据
        res:response 服务端响应的数据
 */
let server = http.createServer((req,res)=>{
    //服务端每收到一个客户端请求都会执行一次该回调函数，这个函数会执行多次

    //req.url:获取客户端请求的路径
    console.log('客户端请求的数据' + req.url);
    
});

//3.启动服务器（相当于点击了phpStuty的开启按钮）
/*
第一个参数：端口号
第二个参数：ip地址   默认不写，就是本机ip（127.0.0.1）
第三个参数 
 */
server.listen(3000,'127.0.0.1',(err)=>{
     console.log('服务器启动成功');
});
```



### 1.4.2-响应客户端请求



```javascript
//1.导入HTTP模块
const http = require('http');

//2.创建服务器
let server = http.createServer((req,res)=>{
    //服务器每收到一次请求都会调用一次这个函数
    //req:负责接收客户端请求
    //res:负责响应客户端请求
    
    /* 注意：服务器响应给客户端只能是两种数据类型： 一：文本  二：二进制  否则程序报错 */
    res.end('hello world');
});

//3.开启服务器
server.listen(3000,(err)=>{
    console.log('服务器开启成功'); 
});
```



### 1.4.3-根据不同请求响应不同数据



```javascript
//1.导入HTTP模块
const http = require('http');

//2.创建服务器
let server = http.createServer((req,res)=>{
    //服务器每收到一次请求都会调用一次这个函数
    //req:负责接收客户端请求
    //res:负责响应客户端请求
    
    console.log(req.url);//获取到的内容是127.0.0.1：3000后面的内容，url路径通常以'/'开头
    if(req.url == '/a'){
        res.end('hello world');
    }else if(req.url == '/login'){//

        //设置服务器响应头： 作用：服务端告诉客户端，我响应给你的数据是什么类型
        res.writeHead(200,{
            'Content-Type':'text/plain;charset=utf8'   //text/plain:普通文本
        });

        res.end('这是登录页');
    }else if(req.url == '/'){ //如果本次没有请求路径（127.0.0.1：3000），通常表示首页
        
        res.writeHead(200,{
            'Content-Type':'text/html;charset=utf8'   //text/html文本
        });
        res.end('<h1>这是首页</h1>');
    }else{
        //如果客户端请求了服务端无法识别的路径，一般响应404
        res.end('404 not found');
    };
});

//3.开启服务器
server.listen(3000,()=>{
  
    console.log('服务器开启成功');

})
```



### 1.4.4-http响应客户端HTML文件



```javascript
//1.导入http模块
const http = require('http');

const fs = require('fs');

//2.创建服务器
let server = http.createServer((req,res)=>{

    console.log(req.url);
    //一般情况下，如果返回的是文件二进制数据，浏览器会自动识别文件格式解析加载
    
    if(req.url == '/'){//  请求路径为/，返回首页
        fs.readFile('./data/index.html',(err,data)=>{
            if(err){
                throw err;
            }else{
                console.log(data);
                res.end(data);
            };
        });
    }else if(req.url == '/login.html'){
        fs.readFile('./data/login.html',(err,data)=>{
            if(err){
                throw err;
            }else{
                res.end(data);
            };
        });
    }else if(req.url == '/image.jpg'){
        fs.readFile('./data/image.jpg',(err,data)=>{
            if(err){
                throw err;
            }else{
                res.end(data);
            };
        });
    }else{
        res.end('404 not found');
    };
});

//3.开启服务器
server.listen(3000,(err)=>{
    console.log('服务器启动成功');
});
```





# 02-[课外拓展]nodejs实现服务端重定向

* **服务端重定向常见于某些网站引导登陆注册的功能（当我们访问网站首页的时候，会跳转到登陆注册的界面）**
* **服务端的重定向功能主要由响应头的302状态码来实现**



```javascript
//1.导入模块
const http = require('http');

const fs = require('fs');

const path = require('path');

//2.创建服务器
let server = http.createServer((req,res)=>{
    console.log(req.url);
    //请求路径
    let urlPath = req.url;
    //请求方法
    let  method = req.method;

    if(req.url === '/'){
        //302表示重定向
        //(1)设置重定向地址
        res.writeHead(302, {
            'Location': 'login'  //键值对，键表示客户端浏览器将进行重定向  值：表示客户端浏览器重定向的请求
            //add other headers here...
        });
        //(2)响应本次请求
        res.end();
    }
    //登陆页
    if(req.url === '/login'){
        fs.readFile(path.join(__dirname,'login.html'),function(err,data){
            if(err){
                throw err;
            }
            res.end(data);
        });
    };
});


//3.开启服务器
server.listen(3000,  ()=> {
    console.log('服务器启动成功');
});
```



# 03-[课后了解]nodejs断点调试



* 1.点击vscode左侧小虫子图标

![1571412441483](day02.assets/1571412441483.png)

* 2.点击绿色运行按钮，在弹出提示框中选择nodejs

![1571412519592](day02.assets/1571412519592.png)

* 3.在弹出的launch.json文件中添加配置(建议将我的配置完全复制粘贴)

![1571412586505](day02.assets/1571412586505.png)

```javascript
{
    "version": "0.2.0",
    "configurations": [
        {
            "type": "node",
            "request": "launch",
            "name": "debug",
            "program": "${file}",//当前文件
            "cwd": "${cwd}" //在哪个文件就从哪个文件调试
        }
    ]
}
```

* 4.给你想要的js文件左侧添加断点

![1571412770428](day02.assets/1571412770428.png)



* 5.开始调试

![1571412879040](day02.assets/1571412879040.png)